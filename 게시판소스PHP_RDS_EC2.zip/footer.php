        <div id="footer_content">
            <p id="footer_logo">PHP 프로그래밍 입문 | <span>한국공학대</span></p>
            <ul id="download">
   
                <li>- 홈으로(http://)</li>

            </ul>
            <ul id="author">
                <li>관리자</li>
                <li>- 메일 주소 : gpark@tukorea.ac.kr</li>
            </ul>
        </div>